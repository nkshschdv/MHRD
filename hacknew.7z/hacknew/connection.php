<?php
 $m=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($m,"hack");
?>